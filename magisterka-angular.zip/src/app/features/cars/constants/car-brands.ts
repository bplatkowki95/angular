
export const carBrands = [
    'Volkswagen',
    'Audi',
    'Renault',
    'BMW',
    'Mercedes',
    'Volvo',
    'Honda',
    'Jaguar',
    'Ford',
    'Fiat'
];
