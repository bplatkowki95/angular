
export class Car {
    public vin: string;
    public year: number;
    public brand: string;
    public color: string;
    public model: string;
    public price: number;
    constructor() {
    }
}
